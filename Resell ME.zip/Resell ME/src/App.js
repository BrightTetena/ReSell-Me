import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min";
import "./App.css";
import "./About.css";
import "./GetStartedCards.css"
import Banner from "./assets/components/Banner";
import About from "./assets/components/About";
import GetStartedCards from "./assets/components/GetStartedCards";

function App() {
  return (
    <>
      <div className="sticky-top">

        <Banner/>
        <About/>
        <GetStartedCards/>
      </div>
    </>
  );
}

export default App;